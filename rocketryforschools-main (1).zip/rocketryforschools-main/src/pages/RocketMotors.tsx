
import { useEffect } from "react";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { useToast } from "@/hooks/use-toast";
import RevealAnimation from "@/components/ui/RevealAnimation";
import ProductCard from "@/components/ui/ProductCard";

// Sample rocket motors data
const rocketMotors = [
  {
    id: '1',
    name: 'A8-3 Rocket Motors (Pack of 3)',
    description: 'Entry-level rocket motors suitable for small model rockets. Perfect for beginners and school projects.',
    price: 12.99,
    image: 'https://images.unsplash.com/photo-1614726365952-510103b9eda5?q=80&w=1064&auto=format&fit=crop&ixlib=rb-4.0.3',
  },
  {
    id: '2',
    name: 'B6-4 Rocket Motors (Pack of 3)',
    description: 'Medium-power rocket motors with longer burn time. Great for intermediate rockets with higher altitude capability.',
    price: 15.99,
    image: 'https://images.unsplash.com/photo-1534088568595-a066f410bcda?q=80&w=1051&auto=format&fit=crop&ixlib=rb-4.0.3',
  },
  {
    id: '3',
    name: 'C6-5 Rocket Motors (Pack of 3)',
    description: 'Higher-power rocket motors for advanced model rockets. Provides significant thrust for larger rocket designs.',
    price: 18.99,
    image: 'https://images.unsplash.com/photo-1532968969795-a229a86f92af?q=80&w=1064&auto=format&fit=crop&ixlib=rb-4.0.3',
  },
  {
    id: '4',
    name: 'D12-7 Rocket Motors (Pack of 2)',
    description: 'High-power rocket motors for experienced rocketeers. Perfect for advanced school demonstrations and competitions.',
    price: 22.99,
    image: 'https://images.unsplash.com/photo-1569033083669-a267a7c56d94?q=80&w=1064&auto=format&fit=crop&ixlib=rb-4.0.3',
  },
  {
    id: '5',
    name: 'E9-6 Rocket Motors (Single)',
    description: 'Advanced rocket motor with significant thrust. For use by experienced educators and in supervised school settings.',
    price: 24.99,
    image: 'https://images.unsplash.com/photo-1614726365952-510103b9eda5?q=80&w=1064&auto=format&fit=crop&ixlib=rb-4.0.3',
  },
  {
    id: '6',
    name: 'Educator\'s Motor Variety Pack',
    description: 'Mixed pack containing A, B, and C class motors. Perfect for classroom demonstrations and comparing motor performance.',
    price: 34.99,
    image: 'https://images.unsplash.com/photo-1614315517650-3771cf72d18a?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3',
  },
];

const RocketMotors = () => {
  const { toast } = useToast();

  useEffect(() => {
    // Add intersection observer for animation
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('appear');
        }
      });
    }, { threshold: 0.1 });

    // Observe all elements with section-animate class
    document.querySelectorAll('.section-animate').forEach((el) => {
      observer.observe(el);
    });

    return () => {
      // Cleanup
      document.querySelectorAll('.section-animate').forEach((el) => {
        observer.unobserve(el);
      });
    };
  }, []);

  return (
    <div className="min-h-screen bg-white dark:bg-space-950 text-space-900 dark:text-white">
      {/* Navbar */}
      <Navbar />
      
      {/* Main Content */}
      <main className="max-w-[80%] mx-auto pt-28 pb-16">
        <section className="py-12 bg-white dark:bg-space-950 relative overflow-hidden">
          {/* Noise texture overlay */}
          <div className="absolute inset-0 bg-noise opacity-[0.02] pointer-events-none" />
          
          <div className="container px-6 mx-auto">
            {/* Section header */}
            <RevealAnimation>
              <div className="text-center max-w-2xl mx-auto mb-16">
                <span className="px-3 py-1 text-xs font-medium bg-space-100 dark:bg-space-800 text-space-800 dark:text-space-200 rounded-full mb-4 inline-block">
                  Rocket Motors
                </span>
                <h1 className="text-3xl md:text-4xl font-bold mb-6">
                  Educational <span className="text-rocket-600 dark:text-rocket-400">Rocket Motors</span>
                </h1>
                <p className="text-space-600 dark:text-space-400">
                  Explore our range of safe, reliable rocket motors for educational use. All motors are suitable for classroom demonstrations and school rocketry projects under supervision.
                </p>
              </div>
            </RevealAnimation>

            {/* Motors Safety Notice */}
            <RevealAnimation delay={0.2}>
              <div className="bg-space-50 dark:bg-space-900 p-6 rounded-lg mb-12 border-l-4 border-rocket-500">
                <h3 className="text-xl font-semibold mb-2">Important Safety Notice</h3>
                <p className="text-space-600 dark:text-space-400 mb-4">
                  All rocket motors must be used under adult supervision and in accordance with UK model rocketry laws. Please review our safety guidelines and legal requirements before purchase.
                </p>
                <p className="text-space-600 dark:text-space-400">
                  Motors are classified by their total impulse (A, B, C, etc.) which indicates their power. Higher letter means more power and requires more space for launching.
                </p>
              </div>
            </RevealAnimation>

            {/* Products grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
              {rocketMotors.map((motor, index) => (
                <RevealAnimation key={motor.id} delay={0.1 * (index % 3)}>
                  <ProductCard 
                    id={motor.id}
                    name={motor.name}
                    description={motor.description}
                    price={motor.price}
                    image={motor.image}
                  />
                </RevealAnimation>
              ))}
            </div>
          </div>
        </section>
      </main>
      
      {/* Footer */}
      <Footer />
    </div>
  );
};

export default RocketMotors;
