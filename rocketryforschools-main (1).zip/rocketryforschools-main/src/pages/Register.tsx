
import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { UserPlus, Eye, EyeOff, ArrowRight } from 'lucide-react';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import AnimatedButton from '@/components/ui/AnimatedButton';
import RevealAnimation from '@/components/ui/RevealAnimation';
import { Helmet } from 'react-helmet';

const Register = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (password !== confirmPassword) {
      toast({
        title: "Password error",
        description: "Passwords do not match",
        variant: "destructive",
      });
      return;
    }
    
    setLoading(true);
    
    try {
      const result = await register(name, email, password);
      
      if (result.success) {
        toast({
          title: "Registration successful",
          description: "Your account has been created",
        });
        navigate('/account');
      } else {
        toast({
          title: "Registration failed",
          description: result.message,
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Registration error",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <div className="min-h-screen bg-white dark:bg-space-950 text-space-900 dark:text-white">
      <Helmet>
        <title>Create Account | Rocketry For Schools</title>
        <meta name="description" content="Create a new Rocketry For Schools account" />
      </Helmet>
      
      <Navbar />
      
      <main className="w-full md:w-[90%] mx-auto pt-28 pb-16 px-4">
        <div className="max-w-md mx-auto">
          <RevealAnimation>
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold mb-2">Create Account</h1>
              <p className="text-space-600 dark:text-space-400">
                Join us to track orders and access educational resources
              </p>
            </div>
          </RevealAnimation>
          
          <RevealAnimation delay={0.1}>
            <div className="bg-white dark:bg-space-900 rounded-xl shadow-sm p-6 sm:p-8">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium mb-1">
                    Full Name
                  </label>
                  <input
                    id="name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-transparent focus:ring-1 focus:ring-rocket-500 focus:border-rocket-500"
                    placeholder="John Smith"
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium mb-1">
                    Email
                  </label>
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-transparent focus:ring-1 focus:ring-rocket-500 focus:border-rocket-500"
                    placeholder="your@email.com"
                  />
                </div>
                
                <div>
                  <label htmlFor="password" className="block text-sm font-medium mb-1">
                    Password
                  </label>
                  <div className="relative">
                    <input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      minLength={6}
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-transparent focus:ring-1 focus:ring-rocket-500 focus:border-rocket-500"
                      placeholder="••••••••"
                    />
                    <button 
                      type="button"
                      onClick={togglePasswordVisibility}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
                    >
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Password must be at least 6 characters
                  </p>
                </div>
                
                <div>
                  <label htmlFor="confirmPassword" className="block text-sm font-medium mb-1">
                    Confirm Password
                  </label>
                  <input
                    id="confirmPassword"
                    type={showPassword ? "text" : "password"}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-transparent focus:ring-1 focus:ring-rocket-500 focus:border-rocket-500"
                    placeholder="••••••••"
                  />
                </div>
                
                <AnimatedButton
                  type="submit"
                  variant="primary"
                  fullWidth
                  icon={<UserPlus size={18} />}
                  iconPosition="left"
                  disabled={loading}
                  className={loading ? "opacity-70 cursor-not-allowed" : ""}
                >
                  {loading ? "Creating account..." : "Create Account"}
                </AnimatedButton>
              </form>
              
              <div className="mt-6 text-center">
                <p className="text-sm text-space-600 dark:text-space-400">
                  Already have an account?{' '}
                  <Link to="/login" className="text-rocket-600 dark:text-rocket-400 hover:underline">
                    Login
                  </Link>
                </p>
              </div>
            </div>
          </RevealAnimation>
          
          <RevealAnimation delay={0.2}>
            <div className="mt-8 flex justify-center">
              <Link to="/" className="text-sm text-space-600 dark:text-space-400 hover:text-rocket-600 dark:hover:text-rocket-400 flex items-center">
                <ArrowRight size={16} className="mr-1 rotate-180" />
                Back to Home
              </Link>
            </div>
          </RevealAnimation>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Register;
