
import { useEffect } from "react";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import RevealAnimation from "@/components/ui/RevealAnimation";
import ProductCard from "@/components/ui/ProductCard";

// Sample school and club kits data
const schoolsClubsKits = [
  {
    id: '1',
    name: 'UKROC Competition Team Kit',
    description: 'Complete kit for school teams participating in the UK Rocketry Challenge. Includes all necessary components and comprehensive instruction manual.',
    price: 149.99,
    image: 'https://images.unsplash.com/photo-1518364538800-6bae3c2ea0f2?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80',
  },
  {
    id: '2',
    name: 'Classroom Group Kit (30 Students)',
    description: 'Comprehensive kit for classroom activities. Contains materials for 10 model rockets, allowing 30 students to work in groups of 3. Includes teacher resources and lesson plans.',
    price: 299.99,
    image: 'https://images.unsplash.com/photo-1567416661576-659cd640d568?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80',
  },
  {
    id: '3',
    name: 'STEM Club Starter Kit',
    description: 'Perfect for school STEM clubs starting with rocketry. Includes 5 different model rocket designs, motors, launch equipment, and educational materials.',
    price: 199.99,
    image: 'https://images.unsplash.com/photo-1457364559154-aa2644600ebb?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80',
  },
  {
    id: '4',
    name: 'Primary School Introduction Kit',
    description: 'Specially designed for younger students. Simple, safe rockets with water and air pressure propulsion. Includes colorful materials and age-appropriate instructions.',
    price: 89.99,
    image: 'https://images.unsplash.com/photo-1599498448014-83f4b187d49d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80',
  },
  {
    id: '5',
    name: 'Advanced Physics Curriculum Kit',
    description: 'Designed for A-level Physics classes. Includes advanced rocket designs, precision measurement equipment, and comprehensive curriculum materials aligned with exam specifications.',
    price: 249.99,
    image: 'https://images.unsplash.com/photo-1581091014534-999cc619231d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80',
  },
  {
    id: '6',
    name: 'Multi-Launch Event Kit',
    description: 'Everything needed for a school rocket launch event. Includes 20 rocket kits, launch equipment, safety materials, and event planning guide.',
    price: 399.99,
    image: 'https://images.unsplash.com/photo-1516849841032-87cbac4d88f7?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80',
  },
];

const SchoolsClubsKits = () => {
  useEffect(() => {
    // Add intersection observer for animation
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('appear');
        }
      });
    }, { threshold: 0.1 });

    // Observe all elements with section-animate class
    document.querySelectorAll('.section-animate').forEach((el) => {
      observer.observe(el);
    });

    return () => {
      // Cleanup
      document.querySelectorAll('.section-animate').forEach((el) => {
        observer.unobserve(el);
      });
    };
  }, []);

  return (
    <div className="min-h-screen bg-white dark:bg-space-950 text-space-900 dark:text-white">
      {/* Navbar */}
      <Navbar />
      
      {/* Main Content */}
      <main className="max-w-[80%] mx-auto pt-28 pb-16">
        <section className="py-12 bg-white dark:bg-space-950 relative overflow-hidden">
          {/* Noise texture overlay */}
          <div className="absolute inset-0 bg-noise opacity-[0.02] pointer-events-none" />
          
          <div className="container px-6 mx-auto">
            {/* Section header */}
            <RevealAnimation>
              <div className="text-center max-w-2xl mx-auto mb-16">
                <span className="px-3 py-1 text-xs font-medium bg-space-100 dark:bg-space-800 text-space-800 dark:text-space-200 rounded-full mb-4 inline-block">
                  Educational Rocketry
                </span>
                <h1 className="text-3xl md:text-4xl font-bold mb-6">
                  Model Rocket Kits for <span className="text-rocket-600 dark:text-rocket-400">Schools & Clubs</span>
                </h1>
                <p className="text-space-600 dark:text-space-400">
                  Specialized model rocketry kits designed for educational institutions, including UKROC competition kits, classroom sets, and STEM club resources.
                </p>
              </div>
            </RevealAnimation>

            {/* Educational Benefits */}
            <RevealAnimation delay={0.2}>
              <div className="bg-space-50 dark:bg-space-900 p-6 rounded-lg mb-12">
                <h3 className="text-xl font-semibold mb-2">Perfect for Educational Settings</h3>
                <ul className="list-disc pl-5 space-y-2 text-space-600 dark:text-space-400">
                  <li>Bulk discounts available for schools and educational institutions</li>
                  <li>Comprehensive teacher guides and lesson plans included</li>
                  <li>Aligned with national curriculum standards</li>
                  <li>Safety-focused designs suitable for classroom environments</li>
                  <li>Support for UK Rocketry Challenge (UKROC) participants</li>
                </ul>
              </div>
            </RevealAnimation>

            {/* Products grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
              {schoolsClubsKits.map((kit, index) => (
                <RevealAnimation key={kit.id} delay={0.1 * (index % 3)}>
                  <ProductCard 
                    id={kit.id}
                    name={kit.name}
                    description={kit.description}
                    price={kit.price}
                    image={kit.image}
                  />
                </RevealAnimation>
              ))}
            </div>
          </div>
        </section>
      </main>
      
      {/* Footer */}
      <Footer />
    </div>
  );
};

export default SchoolsClubsKits;
