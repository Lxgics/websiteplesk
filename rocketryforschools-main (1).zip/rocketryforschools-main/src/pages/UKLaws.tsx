
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import RevealAnimation from "@/components/ui/RevealAnimation";

const UKLaws = () => {
  return (
    <div className="min-h-screen bg-white dark:bg-space-950 text-space-900 dark:text-white">
      {/* Navbar */}
      <Navbar />
      
      {/* Main Content */}
      <main className="max-w-[80%] mx-auto pt-28 pb-16">
        <section className="py-12 bg-white dark:bg-space-950 relative overflow-hidden">
          {/* Noise texture overlay */}
          <div className="absolute inset-0 bg-noise opacity-[0.02] pointer-events-none" />
          
          <div className="container px-6 mx-auto">
            {/* Section header */}
            <RevealAnimation>
              <div className="text-center max-w-3xl mx-auto mb-16">
                <span className="px-3 py-1 text-xs font-medium bg-space-100 dark:bg-space-800 text-space-800 dark:text-space-200 rounded-full mb-4 inline-block">
                  Legal Information
                </span>
                <h1 className="text-3xl md:text-4xl font-bold mb-6">
                  UK Model Rocketry <span className="text-rocket-600 dark:text-rocket-400">Laws & Regulations</span>
                </h1>
                <p className="text-space-600 dark:text-space-400">
                  Understanding the legal framework for safely conducting model rocketry activities in educational settings within the United Kingdom.
                </p>
              </div>
            </RevealAnimation>

            <div className="max-w-4xl mx-auto">
              <RevealAnimation delay={0.1}>
                <div className="prose prose-lg dark:prose-invert max-w-none">
                  <div className="bg-space-50 dark:bg-space-900 p-6 rounded-lg mb-10 border-l-4 border-yellow-500">
                    <h3 className="text-xl font-semibold mb-2 mt-0">Important Disclaimer</h3>
                    <p className="mb-0">
                      This information is provided as guidance only and does not constitute legal advice. Regulations may change, and it is the responsibility of educators and organizations to verify current legal requirements before conducting any model rocketry activities.
                    </p>
                  </div>

                  <h2>Overview of UK Model Rocketry Regulations</h2>
                  <p>
                    In the United Kingdom, model rocketry is regulated under several laws to ensure safety and minimize risks. For educational institutions, understanding these regulations is essential before implementing rocketry programs.
                  </p>

                  <h3>Key Regulatory Bodies</h3>
                  <ul>
                    <li><strong>Civil Aviation Authority (CAA)</strong> - Regulates airspace usage and flying objects</li>
                    <li><strong>United Kingdom Rocketry Association (UKRA)</strong> - National body for sport rocketry that provides guidance on safety codes</li>
                    <li><strong>Health and Safety Executive (HSE)</strong> - Oversees safety in educational environments</li>
                  </ul>

                  <h3>Legal Classifications of Model Rockets</h3>
                  <p>
                    Model rockets in the UK are classified by their motor impulse, measured in Newton-seconds (Ns):
                  </p>
                  <ul>
                    <li><strong>Low-Power Rockets (A-G motors)</strong>: 0-160 Ns - Suitable for school use with proper precautions</li>
                    <li><strong>Mid-Power Rockets (H-J motors)</strong>: 160-640 Ns - Typically requires more experience and larger launch sites</li>
                    <li><strong>High-Power Rockets (K+ motors)</strong>: 640+ Ns - Requires UKRA certification and is generally not appropriate for standard school settings</li>
                  </ul>

                  <h3>School Usage Guidelines</h3>
                  <p>
                    For educational institutions, the following guidelines apply:
                  </p>
                  <ul>
                    <li>Schools typically should use only low-power rockets (A-G motors)</li>
                    <li>A comprehensive risk assessment must be completed before any launch activity</li>
                    <li>Launch activities should be supervised by trained staff members</li>
                    <li>Proper notification to local authorities may be required depending on the launch site</li>
                    <li>Schools should maintain appropriate insurance coverage for rocketry activities</li>
                  </ul>

                  <h3>Launch Site Requirements</h3>
                  <p>
                    When conducting launches for educational purposes:
                  </p>
                  <ul>
                    <li>Launch sites must be open areas free from buildings, power lines, and trees</li>
                    <li>Minimum launch site dimensions depend on the motor size being used</li>
                    <li>For A-C motors: minimum 100m × 100m clear area</li>
                    <li>For D-G motors: minimum 300m × 300m clear area</li>
                    <li>Permission must be obtained from the landowner</li>
                    <li>Be mindful of proximity to airports and flight paths</li>
                  </ul>

                  <h3>Rocket Motor Storage</h3>
                  <p>
                    Educational institutions must comply with storage regulations:
                  </p>
                  <ul>
                    <li>Model rocket motors are classified as explosives under UK law</li>
                    <li>Storage must be in a cool, dry place away from sources of heat</li>
                    <li>Schools should have proper storage containers that meet regulatory requirements</li>
                    <li>Detailed inventory records should be maintained</li>
                    <li>Check with your local fire authority regarding specific storage requirements</li>
                  </ul>

                  <h3>Flight Notification Requirements</h3>
                  <p>
                    Depending on the launch parameters, you may need to notify:
                  </p>
                  <ul>
                    <li>The CAA for rockets that may exceed 1,000 feet in altitude</li>
                    <li>Local air traffic control if launching within 5 miles of an airport</li>
                    <li>Local authorities, including police, especially for larger events</li>
                  </ul>

                  <h3>Resources for Educators</h3>
                  <p>
                    We recommend consulting the following resources for more detailed information:
                  </p>
                  <ul>
                    <li>United Kingdom Rocketry Association (UKRA) Safety Code</li>
                    <li>Civil Aviation Authority (CAA) guidelines for model aircraft and rockets</li>
                    <li>CLEAPSS (Consortium of Local Education Authorities for the Provision of Science Services) guidance for schools</li>
                    <li>Association for Science Education (ASE) resources</li>
                  </ul>
                </div>
              </RevealAnimation>
            </div>
          </div>
        </section>
      </main>
      
      {/* Footer */}
      <Footer />
    </div>
  );
};

export default UKLaws;
