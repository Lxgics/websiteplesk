
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import RevealAnimation from "@/components/ui/RevealAnimation";

const Terms = () => {
  return (
    <div className="min-h-screen bg-white dark:bg-space-950 text-space-900 dark:text-white">
      {/* Navbar */}
      <Navbar />
      
      {/* Main Content */}
      <main className="max-w-[80%] mx-auto pt-28 pb-16">
        <section className="py-12 bg-white dark:bg-space-950 relative overflow-hidden">
          {/* Noise texture overlay */}
          <div className="absolute inset-0 bg-noise opacity-[0.02] pointer-events-none" />
          
          <div className="container px-6 mx-auto">
            {/* Section header */}
            <RevealAnimation>
              <div className="text-center max-w-3xl mx-auto mb-16">
                <span className="px-3 py-1 text-xs font-medium bg-space-100 dark:bg-space-800 text-space-800 dark:text-space-200 rounded-full mb-4 inline-block">
                  Legal
                </span>
                <h1 className="text-3xl md:text-4xl font-bold mb-6">
                  Terms of <span className="text-rocket-600 dark:text-rocket-400">Service</span>
                </h1>
                <p className="text-space-600 dark:text-space-400">
                  Please read these terms carefully before using our products or services.
                </p>
              </div>
            </RevealAnimation>

            <div className="max-w-4xl mx-auto">
              <RevealAnimation delay={0.1}>
                <div className="prose prose-lg dark:prose-invert max-w-none">
                  <p>
                    <strong>Last Updated:</strong> May 15, 2023
                  </p>

                  <h2>1. Introduction</h2>
                  <p>
                    Welcome to Rocketry For Schools. These Terms of Service ("Terms") govern your use of our website, products, and services. By accessing our website or purchasing our products, you agree to these Terms.
                  </p>

                  <h2>2. Educational Use</h2>
                  <p>
                    Our products are designed for educational purposes and should be used under proper supervision in accordance with all provided instructions and applicable laws. Rocketry For Schools is not responsible for improper use of our products.
                  </p>

                  <h2>3. Product Safety and Usage</h2>
                  <p>
                    3.1. All products sold by Rocketry For Schools are intended to be used in educational settings under the supervision of qualified educators or adults.
                  </p>
                  <p>
                    3.2. Users must follow all safety guidelines, instructions, and warnings provided with our products.
                  </p>
                  <p>
                    3.3. Users must comply with all applicable local, state, and national laws regarding model rocketry.
                  </p>
                  <p>
                    3.4. Rocket motors and other components must be stored according to recommended guidelines and legal requirements.
                  </p>

                  <h2>4. Ordering and Payment</h2>
                  <p>
                    4.1. Prices for products are as listed on our website at the time of purchase and are subject to change without notice.
                  </p>
                  <p>
                    4.2. All payments must be made in full prior to shipment of products.
                  </p>
                  <p>
                    4.3. We accept various payment methods as indicated during the checkout process.
                  </p>
                  <p>
                    4.4. Educational institutions may request purchase orders subject to our approval.
                  </p>

                  <h2>5. Shipping and Delivery</h2>
                  <p>
                    5.1. Delivery times are estimated and not guaranteed.
                  </p>
                  <p>
                    5.2. Risk of loss and title for all products pass to you upon delivery to the carrier.
                  </p>
                  <p>
                    5.3. Certain products, including rocket motors, may have shipping restrictions due to their classification.
                  </p>

                  <h2>6. Returns and Refunds</h2>
                  <p>
                    6.1. We accept returns of unused, unopened products within 30 days of purchase.
                  </p>
                  <p>
                    6.2. Customers are responsible for return shipping costs unless the return is due to our error.
                  </p>
                  <p>
                    6.3. Some items, particularly safety equipment and rocket motors, may not be returnable due to safety concerns.
                  </p>

                  <h2>7. Warranty</h2>
                  <p>
                    7.1. We warrant that our products will be free from defects in materials and workmanship under normal use for a period of 90 days from the date of purchase.
                  </p>
                  <p>
                    7.2. This warranty does not cover damage resulting from accident, misuse, abuse, or normal wear and tear.
                  </p>
                  <p>
                    7.3. Our liability is limited to replacement or repair of the defective product or refund of the purchase price.
                  </p>

                  <h2>8. Limitation of Liability</h2>
                  <p>
                    8.1. To the maximum extent permitted by law, Rocketry For Schools shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from the use or inability to use our products.
                  </p>
                  <p>
                    8.2. Our total liability for any claim arising out of or relating to our products shall not exceed the amount paid for the product that is the subject of the claim.
                  </p>

                  <h2>9. Privacy Policy</h2>
                  <p>
                    Your use of our website and services is also governed by our Privacy Policy, which is incorporated into these Terms by reference.
                  </p>

                  <h2>10. Changes to Terms</h2>
                  <p>
                    We reserve the right to modify these Terms at any time. Changes will be effective immediately upon posting on our website. Your continued use of our services after any changes constitutes acceptance of those changes.
                  </p>

                  <h2>11. Contact Information</h2>
                  <p>
                    If you have any questions about these Terms, please contact us at:
                  </p>
                  <p>
                    Rocketry For Schools<br />
                    123 Education Lane<br />
                    London, UK<br />
                    Email: info@rocketryforschools.com<br />
                    Phone: +44 20 1234 5678
                  </p>
                </div>
              </RevealAnimation>
            </div>
          </div>
        </section>
      </main>
      
      {/* Footer */}
      <Footer />
    </div>
  );
};

export default Terms;
