
import { useEffect, useRef, useState } from 'react';

// Utility to detect when an element is in viewport
export const useInView = (options = {}, once = true) => {
  const ref = useRef(null);
  const [isInView, setIsInView] = useState(false);

  useEffect(() => {
    const element = ref.current;
    
    if (!element) return;
    
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setIsInView(true);
        if (once) observer.unobserve(element);
      } else {
        if (!once) setIsInView(false);
      }
    }, options);
    
    observer.observe(element);
    
    return () => {
      observer.unobserve(element);
    };
  }, [options, once]);

  return [ref, isInView];
};

// Staggered animation utility
export const useStaggeredAnimation = (count: number, delay = 0.1, baseDelay = 0) => {
  return Array.from({ length: count }).map((_, index) => ({
    transition: {
      delay: baseDelay + index * delay,
    },
  }));
};

// Smooth scroll to element
export const scrollToElement = (elementId: string) => {
  const element = document.getElementById(elementId);
  if (element) {
    element.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
    });
  }
};
